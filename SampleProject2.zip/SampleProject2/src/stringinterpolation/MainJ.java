package stringinterpolation;

public class MainJ {

    public static void main(String[] args) {
        String firstName = "John";
        String secondName = "Paul";
        int age = 18;

        String data = "Name-" + firstName + " " + secondName+", Age-"+age;

        System.out.println("-------------------------------");
        System.out.println(data);
    }
}
