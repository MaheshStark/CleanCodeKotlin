package stringinterpolation

object MainK {

    @JvmStatic
    fun main(args: Array<String>) {
        val firstName = "John"
        val secondName = "Paul"
        val age = 18

        val data = "Name-$firstName $secondName, Age-$age"

        println("-------------------------------")
        println(data)
        println("-------------------------------")
    }
}
