package nullsafety;

import dataclass.PersonJ;

public class MainJ {

    public static void main(String[] args) {
        PersonJ personJ = null;
        personJ.setAge(6);
    }
}
