package nullsafety

import intuitiveequals.PersonK

object MainK2 {

    @JvmStatic
    fun main(args: Array<String>) {
        val personk: PersonK? = null
        val name = personk?.name ?: "unknown"
        println("---------Result-------------")
        println("Name : $name")
    }



}
