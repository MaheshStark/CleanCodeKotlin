package nullsafety;

import dataclass.PersonJ;

public class MainJ2 {

    public static void main(String[] args) {
        PersonJ personJ = null;
        String name = "";
        if (personJ != null) {
            if (personJ.getName() != null) {
                name = personJ.getName();
            } else {
                name = "unknown";
            }
        } else {
            name = "unknown";
        }

        System.out.println("---------Result-------------");
        System.out.println("Name : "+name);
    }

}
