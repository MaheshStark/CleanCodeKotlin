package nullsafety

import intuitiveequals.PersonK

object MainK {

    @JvmStatic
    fun main(args: Array<String>) {
        val personk: PersonK? = null
        personk?.age = 6
    }



}
