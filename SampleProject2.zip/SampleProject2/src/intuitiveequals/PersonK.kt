package intuitiveequals

data class PersonK(var name: String,
                  var age: Int,
                  var height: Float = 1.8f)