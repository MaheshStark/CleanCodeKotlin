package intuitiveequals

object MainK {
    @JvmStatic
    fun main(args: Array<String>) {
        val person1 = PersonK("John", 5,9.0f)
        val person2 = PersonK("John", 5,9.0f)

        val res1 = person1 == person2
        val res2 = person1.equals(person2)
        val res3 = person1 === person2

        println("-------------------------------")
        println("Result of == : $res1")
        println("Result of equals : $res2")
        println("Result of === : $res3")
    }
}
