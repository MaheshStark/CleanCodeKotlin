package intuitiveequals;

import dataclass.PersonJ;

public class MainJ {

    public static void main(String[] args) {
        PersonJ person1 = new PersonJ("John", 5,9.0f);
        PersonJ person2 = new PersonJ("John", 5,9.0f);

        boolean res1 = person1.equals(person2);
        boolean res2 = person1 == person2;

        System.out.println("-------------------------------");
        System.out.println("Result of equals : "+res1);
        System.out.println("Result of == : "+res2);
    }
}
