package dataclass;

public final class PersonJ {
    private String name;
    private int age;
    private float height;

    public PersonJ(String name, int age, float height) {
        this.name = name;
        this.age = age;
        this.height = height;
    }

    public PersonJ(String name, int age) {
        this.name = name;
        this.age = age;
        this.height = 1.8f;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "PersonJ{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", height=" + height +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PersonJ personJ = (PersonJ) o;

        if (age != personJ.age) return false;
        if (Float.compare(personJ.height, height) != 0) return false;
        return name != null ? name.equals(personJ.name) : personJ.name == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + age;
        result = 31 * result + (height != +0.0f ? Float.floatToIntBits(height) : 0);
        return result;
    }
}
