package dataclass

import intuitiveequals.PersonK

object MainK {

    @JvmStatic
    fun main(args: Array<String>) {
        val person = PersonK("John", 25, 10f)
        println("-------------------------------")
        println(person.toString())
        println("-------------------------------")

        val person2 = PersonK("John", 25, 10f)
        val res = person == person2
        println("Equals Result-$res")
        println("-------------------------------")
    }

}
