package dataclass;

public class MainJ {

    public static void main(String[] args) {
        PersonJ person = new PersonJ("John",25,10);
        System.out.println("-------------------------------");
        System.out.println(person.toString());
        System.out.println("-------------------------------");

        PersonJ person2 = new PersonJ("John",25,10);
        boolean res = person.equals(person2);
        System.out.println("Equals Result-"+res);
        System.out.println("-------------------------------");
    }
}
