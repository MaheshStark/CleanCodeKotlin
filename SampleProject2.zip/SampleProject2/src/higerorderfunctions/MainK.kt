package higerorderfunctions

object MainK {
    @JvmStatic
    fun main(args: Array<String>) {
        val res = operations(10, 20, this::sum)
        println("-------------------------------")
        println("Result : $res")
    }

    fun operations(x: Int, y: Int, op: (Int, Int) -> Int): Int {
        return op(x, y)
    }

    fun sum(a: Int, b: Int): Int {
        val total: Int = a + b
        return total
    }
}






