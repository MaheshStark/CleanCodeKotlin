package extensionfunctions

object MainK {
    @JvmStatic
    fun main(args: Array<String>) {
        var text = "Clean Code With Kotlin For Android"
        var result = text.replaceSpaces()
        println("--------------Result-----------------")
        println(result)
    }
}
