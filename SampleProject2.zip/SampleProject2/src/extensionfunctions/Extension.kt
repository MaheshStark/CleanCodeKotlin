package extensionfunctions

fun String.replaceSpaces(): String {
    return this.replace(' ', '_')
}