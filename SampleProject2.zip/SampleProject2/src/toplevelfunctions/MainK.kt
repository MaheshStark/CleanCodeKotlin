package toplevelfunctions

object MainK {

    @JvmStatic
    fun main(args: Array<String>) {
        println("-------------------------------Current DateTime -----------------------")
        val dateTime = getCurrentDateTime()
        println(dateTime)
        println("-------------------------------")
    }
}
