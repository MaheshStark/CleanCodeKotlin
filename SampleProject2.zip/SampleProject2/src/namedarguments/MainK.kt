package namedarguments

object MainK {
    @JvmStatic
    fun main(args: Array<String>) {

        reformat("sample")

        reformat("sample", true, true, false, '_')

        reformat("sample",
            normalizeCase = true,
            upperCaseFirstLetter = true,
            divideByCamelHumps = false,
            wordSeparator = '_'
        )

        reformat("sample", wordSeparator = '_')
    }
}


fun reformat(str: String,
             normalizeCase: Boolean = true,
             upperCaseFirstLetter: Boolean = true,
             divideByCamelHumps: Boolean = false,
             wordSeparator: Char = '#') {
    println("str - $str  wordSeparator - $wordSeparator")

}